<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Mutasi_model;

class Report extends BaseController
{
	public function index()
	{
		$logged = session()->get('logged_in');

		if ($logged == TRUE) {

			$data['menu'] = '';
			echo template('StockCabang/form_report', $data);
		} else {

			return redirect()->to('/auth');
		}
	}
	public function transaksi()
	{

		$model = new Mutasi_model();
		$awal = $this->request->getPost('tglawal');
		$akhir = $this->request->getPost('tglakhir');
		$data = $model->LaporanMutasi($awal, $akhir)->getResult();
		echo json_encode($data);
	}
}
