<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Customers_model;

class Customers extends BaseController
{
    public function index()
    {
        $logged = session()->get('logged_in');

        if ($logged == TRUE) {

            $model = new Customers_model();
            $data['customers']  = $model->getCustomer()->getResult();

            echo template('Penjualan/view_customer', $data);
        } else {

            return redirect()->to('/auth');
        }
    }

    public function getCustomer()
    {


        $model = new Customers_model();
        $data  = $model->getCustomer()->getResult();

        echo json_encode($data);
    }

    public function save()
    {
        $model = new Customers_model();
        $data = array(
            'name_costumer'        => $this->request->getPost('namacustomer'),
            'address_costumer'       => $this->request->getPost('addresscustomer'),
            'telp_costumer' => $this->request->getPost('telpcustomer')
        );
        $data = $model->saveCustomer($data);
        echo json_encode($data);
    }

    public function editCustomer()
    {
        $model = new Customers_model();
        $id = $this->request->getPost('idcustomer'); // dikirim dari :data{idCustomer:idCustomer} ajax
        $data = $model->editCustomer($id)->getResult();
        echo json_encode($data);
    }

    public function updateCustomer()
    {
        $model = new Customers_model();
        $id = $this->request->getPost('idcustomer');
        $data = array(
            'name_costumer'        => $this->request->getPost('namacustomer'),
            'address_costumer'       => $this->request->getPost('addresscustomer'),
            'telp_costumer' => $this->request->getPost('telpcustomer')
        );
        $data = $model->updateCustomer($data, $id);
        echo json_encode($data);
    }

    public function delete()
    {
        $model = new Customers_model();
        $id = $this->request->getPost('idcustomer'); // dikirim dari :data{idCustomer:idCustomer} ajax
        $data = $model->deleteCustomer($id);
        echo json_encode($data);
    }
}
