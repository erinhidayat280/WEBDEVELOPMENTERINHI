<?php

namespace App\Controllers;

use App\Models\Mutasi_model;
use App\Models\Product_model;

class Mutasi extends BaseController
{
    public function index()
    {
        $logged = session()->get('logged_in');

        if ($logged == TRUE) {

            $data['menu'] = '';
            echo template('StockCabang/form_transaksi', $data);
        } else {

            return redirect()->to('/auth');
        }
    }
    public function save()
    {
        $model = new Mutasi_model();
        $pmodel = new Product_model();

        $baris = $this->request->getPost('baris');
        $no = '20';
        $dataHeader = array(
            // 'id_mutasi'        => $no,
            'tgl_mutasi'        => $this->request->getPost('tglmutasi'),
            'store_id'       => $this->request->getPost('idstore'),
            'disc_mutasi' => $this->request->getPost('disc'),
            'total_mutasi' => $this->request->getPost('TotalBayar')
        );
        $data = $model->saveMutasi($dataHeader);

        if ($data) {

            for ($i = 1; $i <= $baris; $i++) {
                $dataDetail = array(
                    'mutasi_id'        => $no,
                    'product_id'       => $this->request->getPost('idproduct' . $i),
                    'product_name'        => $this->request->getPost('nameproduct' . $i),
                    'product_price' => $this->request->getPost('harga' . $i),
                    'product_qty' => $this->request->getPost('jumlah_beli' . $i)
                );

                $id = $this->request->getPost('idproduct' . $i);
                $qty = $this->request->getPost('jumlah_beli' . $i);

                $data = $model->saveDetailMutasi($dataDetail);
                $data = $pmodel->kurangiStock($id, $qty);
            }
            if ($data) {
                echo '200';
            } else {
                echo '300';
            }
        } else {
            echo '300';
        }
    }
    public function transaksi_cetak()
    {
        $model = new Mutasi_model();
        $pmodel = new Product_model();

        $id_mutasi      = $this->input->get('id_mutasi');
        $tgl_mutasi     = $this->input->get('tgl_mutasi');
        $store_id       = $this->input->get('store_id');
        $disc_mutasi    = $this->input->get('disc_mutasi');
        $total_mutasi   = $this->input->get('total_mutasi');

        $this->load->model('m_user');
        $kasir = $this->m_user->get_baris($store_id)->row()->nama;

        $this->load->model('m_pelanggan');
        $pelanggan = 'umum';
        if (!empty($disc_mutasi)) {
            $pelanggan = $this->m_pelanggan->get_baris($disc_mutasi)->row()->nama;
        }

        $this->load->library('cfpdf');
        $pdf = new FPDF('P', 'mm', 'A5');
        $pdf->AddPage();
        $pdf->SetFont('Arial', '', 10);

        $pdf->Cell(25, 4, 'Nota', 0, 0, 'L');
        $pdf->Cell(85, 4, $id_mutasi, 0, 0, 'L');
        $pdf->Ln();
        $pdf->Cell(25, 4, 'tgl_mutasi', 0, 0, 'L');
        $pdf->Cell(85, 4, date('d-M-Y H:i:s', strtotime($tgl_mutasi)), 0, 0, 'L');
        $pdf->Ln();
        $pdf->Cell(25, 4, 'Kasir', 0, 0, 'L');
        $pdf->Cell(85, 4, $kasir, 0, 0, 'L');
        $pdf->Ln();
        $pdf->Cell(25, 4, 'Pelanggan', 0, 0, 'L');
        $pdf->Cell(85, 4, $pelanggan, 0, 0, 'L');
        $pdf->Ln();
        $pdf->Ln();

        $pdf->Cell(130, 5, '-----------------------------------------------------------------------------------------------------------', 0, 0, 'L');
        $pdf->Ln();

        $pdf->Cell(25, 5, 'Kode', 0, 0, 'L');
        $pdf->Cell(40, 5, 'Item', 0, 0, 'L');
        $pdf->Cell(25, 5, 'Harga', 0, 0, 'L');
        $pdf->Cell(15, 5, 'Qty', 0, 0, 'L');
        $pdf->Cell(25, 5, 'Subtotal', 0, 0, 'L');
        $pdf->Ln();

        $pdf->Cell(130, 5, '-----------------------------------------------------------------------------------------------------------', 0, 0, 'L');
        $pdf->Ln();

        $this->load->model('m_barang');
        $this->load->helper('text');

        $no = 0;
        foreach ($_GET['kode_barang'] as $kd) {
            if (!empty($kd)) {
                $nama_barang = $this->m_barang->get_id($kd)->row()->nama_barang;
                $nama_barang = character_limiter($nama_barang, 20, '..');

                $pdf->Cell(25, 5, $kd, 0, 0, 'L');
                $pdf->Cell(40, 5, $nama_barang, 0, 0, 'L');
                $pdf->Cell(25, 5, str_replace(',', '.', number_format($_GET['harga_satuan'][$no])), 0, 0, 'L');
                $pdf->Cell(15, 5, $_GET['jumlah_beli'][$no], 0, 0, 'L');
                $pdf->Cell(25, 5, str_replace(',', '.', number_format($_GET['sub_total'][$no])), 0, 0, 'L');
                $pdf->Ln();

                $no++;
            }
        }

        $pdf->Cell(130, 5, '-----------------------------------------------------------------------------------------------------------', 0, 0, 'L');
        $pdf->Ln();

        // $pdf->Cell(105, 5, 'Total Bayar', 0, 0, 'R');
        // $pdf->Cell(25, 5, str_replace(',', '.', number_format($grand_total)), 0, 0, 'L');
        // $pdf->Ln();

        $pdf->Cell(105, 5, 'total_mutasi', 0, 0, 'R');
        $pdf->Cell(25, 5, str_replace(',', '.', number_format($total_mutasi)), 0, 0, 'L');
        $pdf->Ln();

        // $pdf->Cell(105, 5, 'Kembali', 0, 0, 'R');
        // $pdf->Cell(25, 5, str_replace(',', '.', number_format(($total_mutasi - $grand_total))), 0, 0, 'L');
        // $pdf->Ln();

        $pdf->Cell(130, 5, '-----------------------------------------------------------------------------------------------------------', 0, 0, 'L');
        $pdf->Ln();

        // $pdf->Cell(25, 5, 'Catatan : ', 0, 0, 'L');
        // $pdf->Ln();
        // $pdf->Cell(130, 5, (($catatan == '') ? 'Tidak Ada' : $catatan), 0, 0, 'L');
        // $pdf->Ln();

        // $pdf->Cell(130, 5, '-----------------------------------------------------------------------------------------------------------', 0, 0, 'L');
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Cell(130, 5, "Terimakasih telah berbelanja dengan kami", 0, 0, 'C');

        $pdf->Output();
    }
}
