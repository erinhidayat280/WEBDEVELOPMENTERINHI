<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h2 class="card-header">Laporan</h2>
        </div>
        <form id="formLaporan">
            <div class="card-body">
                <div class="row">
                    <!-- Header Form -->
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                        <div class="form-group col-md-10">
                            <label for="">Tanggal Awal</label>
                            <input type="Date" class="form-control" name="tglawal" id="tglawal" placeholder="Click Here">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                        <div class="form-group col-md-10">
                            <label for="">Tanggal Akhir</label>
                            <input type="Date" class="form-control" name="tglakhir" id="tglakhir" placeholder="Click Here">
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" class="btn btn-primary btn-block" id="btnUpdate">
                <i class="fa fa-floppy-o"></i> Update
            </button>
        </form>
    </div>
    <div class="row">
        <!-- ============================================================== -->
        <!-- data table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Laporan Mutasi</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered second" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Tanggal Mutasi</th>
                                    <th>Nama Store</th>
                                    <th>Nama Produk</th>
                                    <th>Harga Produk</th>
                                    <th>Discount</th>
                                    <th>Total</th>
                                    <!-- <th>Sub Total</th> -->
                                </tr>
                            </thead>
                            <tbody id="tblReport">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end data table  -->
    <!-- ============================================================== -->
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('#btnUpdate').click(function() {
            var dataForm = $('#formLaporan').serialize();
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('Report/transaksi') ?>', //Memanggil Controller/Function
                async: false,
                dataType: 'json',
                data: dataForm,
                success: function(data) {
                    var html = '';
                    var i;
                    var no;
                    for (i = 0; i < data.length; i++) { //looping atau pengulangan
                        no = i + 1;
                        html += '<tr>' +
                            '<td>' + no + '</td>' +
                            '<td>' + data[i].tgl_mutasi + '</td>' +
                            '<td>' + data[i].name_store + '</td>' +
                            '<td>' + data[i].product_name + '</td>' +
                            '<td>' + data[i].product_price + '</td>' +
                            '<td>' + data[i].disc_mutasi + '</td>' +
                            '<td>' + data[i].total_mutasi + '</td>' +
                            '</tr>';
                    } // akhir dari looping

                    $('#tblReport').html(html); // mengirim data
                }
            });
        });
    });
</script>