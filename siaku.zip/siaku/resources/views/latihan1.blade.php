<html>
    <body>
        <h1>Hello, Nama Saya {{ $biodata['name'] }}</h1>
        <p>Saya Dari Kelas {{ $biodata['kelas'] }}</p>
        <p>Hobi Saya {{ $biodata['hobi'] }}</p>
        <p>Tempat Tanggal Lahir {{ $biodata['tempat tanggal lahir'] }}</p>

        <h2>Status</h2>

        <p>Saya Sebagai {{ $status['posisi']}} di {{$status['instansi']}}</p>
        <p>Sebagai Warga Negara {{$status['wn']}}</p>
        <p>Dan Beragama {{ $status['agama']}}</p>

        <h3>Pengalaman</h3>
        <p>Saya Pernah Mengikuti {{ $pengalaman['lomba']}} di {{$pengalaman['tempat']}}</p>
        <p>Lomba Tingkat {{$pengalaman['tkt']}}</p>
        <p>Dan Saya Mengalami Hasil Yang Kurang {{ $pengalaman['feel']}}</p>

    <body>
</html>