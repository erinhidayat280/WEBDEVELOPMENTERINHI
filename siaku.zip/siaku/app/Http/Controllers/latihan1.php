<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;

class latihan1 extends Controller
{
    /**
     * Show the profile for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function biodata()
    {
        $ehi['status'] = array (
            'wn' => 'Indonesia',
            'agama' => 'Isalam',
            'instansi' => 'PT.Alim Rugi Hoyong Untung',
            'posisi' => 'Direktur');
          

        $ehi['biodata'] = array (
            'name' => 'Dewangga Pramana Poetra RUNGKAD POKOKNAMAH',
            'kelas' => 'IK19B',
            'hobi' => 'Berenang',
            'tempat tanggal lahir' => 'Tasikmalaya 02 Agustus 2000');

            $ehi['pengalaman'] = array (
                'lomba' => 'Olimpiade Jaringan',
                'tempat' => 'LPKIA Bandung',
                'tkt' => 'Nasional',
                'feel' => 'Memuaskan');
        
            return view ('latihan1',$ehi);
    }
}