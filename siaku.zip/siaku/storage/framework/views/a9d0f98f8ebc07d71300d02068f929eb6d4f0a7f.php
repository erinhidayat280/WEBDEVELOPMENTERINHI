<html>
    <body>
        <h1>Hello, Nama Saya <?php echo e($biodata['name']); ?></h1>
        <p>Saya Dari Kelas <?php echo e($biodata['kelas']); ?></p>
        <p>Hobi Saya <?php echo e($biodata['hobi']); ?></p>
        <p>Tempat Tanggal Lahir <?php echo e($biodata['tempat tanggal lahir']); ?></p>

        <h2>Status</h2>

        <p>Saya Sebagai <?php echo e($status['posisi']); ?> di <?php echo e($status['instansi']); ?></p>
        <p>Sebagai Warga Negara <?php echo e($status['wn']); ?></p>
        <p>Dan Beragama <?php echo e($status['agama']); ?></p>

        <h3>Pengalaman</h3>
        <p>Saya Pernah Mengikuti <?php echo e($pengalaman['lomba']); ?> di <?php echo e($pengalaman['tempat']); ?></p>
        <p>Lomba Tingkat <?php echo e($pengalaman['tkt']); ?></p>
        <p>Dan Saya Mengalami Hasil Yang Kurang <?php echo e($pengalaman['feel']); ?></p>

    <body>
</html><?php /**PATH C:\xampp\htdocs\siaku\resources\views/latihan1.blade.php ENDPATH**/ ?>